# connectors/git_connector.py

import os
import shutil
import git
from urllib.parse import urlparse

def clone_repo(repo_url: str, dest_root: str = "../data/raw") -> str:
    """
    Clones a Git repository into the data/raw/ folder.

    Args:
        repo_url (str): The URL of the Git repository.
        dest_root (str): Base directory to store the raw repositories.

    Returns:
        str: Path to the cloned repository.
    """
    # Extract repo name
    parsed_url = urlparse(repo_url)
    repo_name = os.path.splitext(os.path.basename(parsed_url.path))[0]
    dest_path = os.path.join(dest_root, repo_name)

    # If already exists, delete and reclone
    if os.path.exists(dest_path):
        print(f"[INFO] Removing existing repo at {dest_path}")
        shutil.rmtree(dest_path)

    print(f"[INFO] Cloning {repo_url} into {dest_path}")
    try:
        git.Repo.clone_from(repo_url, dest_path)
        print("[SUCCESS] Repository cloned successfully.")
        return dest_path
    except Exception as e:
        print(f"[ERROR] Failed to clone repository: {e}")
        return ""
