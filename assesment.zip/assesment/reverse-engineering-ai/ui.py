import streamlit as st
import requests
import json

st.title("Code Assistant Query")

query = st.text_input("Enter your question:")

if st.button("Ask") and query.strip():
    try:
        response = requests.post(
            "http://localhost:8000/query",
            json={"query": query}
        )
        if response.status_code == 200:
            data = response.json()
            # Show llm_answer in Streamlit sidebar (console-like)
            st.sidebar.header("LLM Answer (Console)")
            st.sidebar.text(data["llm_answer"])

            # Show context JSON in main page inside expandable box
            st.subheader("Context (JSON)")

            context_json = json.dumps(data["context"], indent=2)
            with st.expander("Show Context Details"):
                st.code(context_json, language="json")

        else:
            st.error(f"API Error: {response.status_code}")

    except Exception as e:
        st.error(f"Request failed: {e}")
else:
    st.info("Enter a query and press Ask")