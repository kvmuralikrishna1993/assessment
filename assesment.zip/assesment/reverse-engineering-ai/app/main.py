from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import logging
import json
import joblib
import networkx as nx
import numpy as np
from contextlib import asynccontextmanager
import os
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from llama_cpp import Llama
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("app")

class QueryRequest(BaseModel):
    query: str

embedding_data = None
embedding_texts = None
clustering_model = None
code_graph = None
embedding_model = None
embedding_clusters = None
llm_model = None


def load_local_llm():
    global llm_model
    LLM_MODEL_PATH = os.path.join(BASE_DIR, "../models/local_llm/deepseek-coder-6.7B-instruct.Q4_K_M.gguf")
    llm_model = Llama(model_path=LLM_MODEL_PATH)
    print("✓ Local LLM loaded.")

@asynccontextmanager
async def lifespan(app: FastAPI):
    global embedding_data, embedding_texts, clustering_model, code_graph, embedding_model,embedding_clusters
    try:
        # Load embedding model to encode queries
        logger.info("🔄 Loading embedding model...")
        embedding_model = SentenceTransformer(os.path.join(BASE_DIR, "../models/embedding_model"))
        logger.info("✅ Embedding model loaded.")

        # Load all embeddings from multiple JSON files
        logger.info("🔄 Loading embeddings from JSON files...")
        all_embeddings = []
        all_texts = []
        EMBEDDING_FOLDER = os.path.join(BASE_DIR, "../data/embeddings")
        for fname in os.listdir(EMBEDDING_FOLDER):
            if fname.endswith(".json"):
                path = os.path.join(EMBEDDING_FOLDER, fname)
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for item in data:
                        all_embeddings.append(item["embedding"])
                        all_texts.append(item["text"])
        embedding_data = all_embeddings
        embedding_texts = all_texts
        logger.info(f"✅ Loaded {len(embedding_data)} embeddings.")

        # Load clustering model
        logger.info("🔄 Loading clustering model...")
        clustering_model = joblib.load(os.path.join(BASE_DIR, "../data/cluster/kmeans_model.joblib"))
        cluster_labels = clustering_model.predict(np.array(embedding_data, dtype=np.float32))
        embedding_clusters = cluster_labels  # same length as embedding_data
        logger.info("✅ Clustering model loaded.")

        # Load code graph
        logger.info("🔄 Loading code graph...")
        with open(os.path.join(BASE_DIR, "../data/graph/code_graph.json"), "r", encoding="utf-8") as f:
            graph_json = json.load(f)
            code_graph = nx.node_link_graph(graph_json)
        logger.info(f"✅ Code graph loaded with {code_graph.number_of_nodes()} nodes and {code_graph.number_of_edges()} edges.")

        load_local_llm()

        logger.info("🚀 All models loaded successfully.")
        yield
    except Exception as e:
        logger.error(f"❌ Failed to load models on startup: {e}")
        raise
    finally:
        logger.info("📴 Application shutdown.")

app = FastAPI(title="Reverse Engineering AI Inference API", lifespan=lifespan)

def embed_query(query: str):
    if embedding_model is None:
        logger.warning("Embedding model not loaded, returning dummy vector")
        dim = len(embedding_data[0]) if embedding_data else 10
        return np.random.rand(dim).astype(np.float32)

    logger.info(f"Embedding query: {query}")
    embedding = embedding_model.encode([query])[0]  # Correct usage
    return embedding.astype(np.float32)  # ✅ Ensure float32

def extract_related_graph_nodes(top_chunks, code_graph):
    graph_nodes = []
    for chunk in top_chunks:
        for node in code_graph.nodes:
            if node in chunk["text"]:
                node_data = code_graph.nodes[node]
                graph_nodes.append({
                    "node": node,
                    "type": node_data.get("type"),
                })
    return graph_nodes

def truncate_prompt(prompt: str, max_tokens: int = 512) -> str:
    # Rough estimate: 1 token ≈ 4 chars
    max_chars = max_tokens * 4
    if len(prompt) > max_chars:
        # Keep last part (more recent context)
        return prompt[-max_chars:]
    return prompt

def call_llm(prompt: str) -> str:
    if llm_model is None:
        raise RuntimeError("LLM model not loaded. Call `load_local_llm()` first.")
    prompt = truncate_prompt(prompt,350)
    result = llm_model(prompt, max_tokens=512, stop=["</s>"])
    return result["choices"][0]["text"].strip()

def call_llm(prompt: str) -> str:
    if llm_model is None:
        raise RuntimeError("LLM model not loaded. Call `load_local_llm()` first.")

    truncated_prompt = truncate_prompt(prompt, max_tokens=340)

    result = llm_model(truncated_prompt,
        max_tokens=512,       # Increase to get longer answers
        temperature=0.7,       # Optional: adds creativity
        top_p=0.95,            # Optional: nucleus sampling
        stop=["</s>"],         # Remove or keep depending on behavior
    )
    return result["choices"][0]["text"].strip()

def clean_graph_nodes(nodes):
    # Convert list of dicts to unique set by 'node' value
    unique_nodes = {}
    for node in nodes:
        name = node.get("node", "").strip()
        # Filter out short or generic meaningless names
        if len(name) <= 3:
            continue
        if name.lower() in {"function", "func", "takes", "returns", "output", "prev", "clear", "mode", "ratio", "show"}:
            continue
        # Add only unique nodes
        unique_nodes[name] = node
    # Return list of unique, cleaned nodes
    return list(unique_nodes.values())

@app.post("/query")
def query_model(data: QueryRequest):
    if clustering_model is None or code_graph is None:
        logger.error("Models are not loaded, cannot process query")
        raise HTTPException(status_code=503, detail="Models not loaded")

    try:
        logger.info(f"Received query: {data.query}")

        # Step 1: Embed the query
        query_vec = embed_query(data.query).reshape(1, -1).astype(np.float32)

        # Step 2: Predict cluster label
        cluster_label = clustering_model.predict(query_vec)[0]

        # Step 3: Filter embeddings in the same cluster
        cluster_indices = [i for i, label in enumerate(embedding_clusters) if label == cluster_label]
        cluster_embeddings = np.array([embedding_data[i] for i in cluster_indices], dtype=np.float32)
        cluster_texts = [embedding_texts[i] for i in cluster_indices]

        # Step 4: Compute cosine similarity and pick top matches
        sims = cosine_similarity(query_vec, cluster_embeddings)[0]
        top_indices = np.argsort(sims)[::-1][:5]  # Top 5 chunks

        # Step 5: Prepare and clean context chunks - filter low similarity and truncate text
        top_chunks = []
        for i in top_indices:
            if sims[i] < 0.3:
                continue  # Skip low similarity chunk
            text = cluster_texts[i]
            # Optional: truncate long chunk text (e.g. max 1000 chars)
            if len(text) > 1000:
                text = text[:1000] + " ... [truncated]"
            top_chunks.append({
                "text": text,
                "similarity": float(sims[i])
            })

        # Step 6: Retrieve and filter graph nodes (only function names longer than 3 chars)
        raw_nodes = extract_related_graph_nodes(top_chunks, code_graph)
        related_graph_nodes = clean_graph_nodes(raw_nodes)

        # Step 7: Build LLM prompt using only cleaned context
        context_text = "\n\n".join([chunk["text"] for chunk in top_chunks])
        prompt = f"""
        You are a helpful code assistant. Given the following relevant code snippets:

        {context_text}

        Please answer this question based on the context:
        {data.query}
        """

        # Step 8: Call LLM with prompt
        llm_answer = call_llm(prompt)

        logger.info(f"Returning cluster {cluster_label} with LLM answer.")
        return {
            "query": data.query,
            "llm_answer": llm_answer,
            "context": {
                "cluster": int(cluster_label),
                "top_chunks": top_chunks,
                "graph_nodes": related_graph_nodes,
            }
        }

    except Exception as e:
        logger.error(f"Error processing query: {e}")
        raise HTTPException(status_code=500, detail="Query processing failed")