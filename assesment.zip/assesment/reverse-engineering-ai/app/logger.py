import logging
import os

def setup_app_logger(log_file_path="../logs/latest.log"):
    os.makedirs(os.path.dirname(log_file_path), exist_ok=True)

    logger = logging.getLogger("AppLogger")
    logger.setLevel(logging.INFO)  # Change to DEBUG if you want more details

    # Console handler - INFO level
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    ch.setFormatter(ch_formatter)

    # File handler - DEBUG level for detailed logs
    fh = logging.FileHandler(log_file_path)
    fh.setLevel(logging.DEBUG)
    fh_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s")
    fh.setFormatter(fh_formatter)

    if not logger.hasHandlers():
        logger.addHandler(ch)
        logger.addHandler(fh)

    return logger