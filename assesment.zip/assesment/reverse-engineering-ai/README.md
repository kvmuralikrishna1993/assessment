# 🧠 Code Intelligence Assistant

An AI-powered reverse engineering tool that analyzes Python repositories to provide semantic insights and intelligent question answering using a local LLM. It performs code parsing, semantic embedding, clustering, and flow graph generation to help you understand codebases faster and more effectively.

---

## 📌 Source Repository

This app was built using **GPT automation** to process and analyze the open-source repository:  
🔗 [TheAlgorithms/Python](https://github.com/TheAlgorithms/Python)

---

## 🚀 Features

- Clone and analyze code repositories
- Extract source code, comments, and docstrings
- Generate sentence embeddings using `sentence-transformers`
- Cluster semantically similar code blocks
- Build graph structures to map code flow (internal use)
- Run local LLM (CPU-based GGUF model)
- Streamlit-based UI for user queries
- FastAPI-based backend for contextual Q&A

---

## 📁 Folder Structure

```project-root/
├── app/
│   ├── main.py             # FastAPI app
│   ├── logger.py/          # Logger uitlity
├── ui.py                   # Streamlit UI script
├── requirements.txt
├── models/
│   ├── embedding_model/    # SentenceTransformer saved model
│   ├── clustering_model/   # Trained clustering model
│   └── local_llm/          # GGUF LLM files
│       └── deepseek-coder-6.7b-instruct.Q4_K_M.gguf
├── connector/              # Connector to Clone from GitHub repo (e.g., TheAlgorithms/Python)
├── data/                   # Extracted and preprocessed code chunks
├── preprocess/             # Scripts for preprocessing(cloning, extracting, downloading models, generating embeddings, clustering and graph analysis)
└── README.md               # Project overview (you are here!)
```
---

## 🧠 Models and Configuration

```python
EMBED_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
EMBED_MODEL_PATH = "../models/embedding_model"
CLUSTER_MODEL_PATH = "../models/clustering_model"
LLM_MODEL_REPO = "TheBloke/deepseek-coder-6.7B-instruct-GGUF"
LLM_MODEL_FILENAME = "deepseek-coder-6.7b-instruct.Q4_K_M.gguf"
LLM_MODEL_PATH = f"../models/local_llm/{LLM_MODEL_FILENAME}"
```
• Embedding: **all-MiniLM-L6-v2 from SentenceTransformers**

• Vector Indexing: **Done using internal utilities of SentenceTransformer**

• Clustering: **Performed using scikit-learn algorithms**

• LLM: **DeepSeek Coder 6.7B Instruct (GGUF) - runs on CPU**

• Graph: **Logical mapping of functions/classes (used internally only)**

## ⚙️ Setup & Usage

### 1.1 Clone and Setup

```
git clone <your-repo>
cd <your-repo>
pip install -r requirements.txt
```
Ensure your models are placed correctly in the models/ directory.

### 1.2 Run Preprocessing Script (CRUCIAL STEP)

[run_preprocessing.py](preprocess/run_preprocessing.py) -> ```python run_preprocessing.py```

This script performs:

• Cloning and analyzing the repo

• Extracting code + comments

• Creating embeddings

• Clustering code

• Generating internal graph

• Downloading the required LLM models

⸻

### 2. Start the Backend (FastAPI)

```uvicorn app.main:app --reload```

API will be available at: http://localhost:8000

Swagger UI: http://localhost:8000/docs#/default/query_model_query_post

⸻

### 3. Start the Frontend (Streamlit)

```streamlit run ui.py```


⸻

💬 Sample Query

✅ Request

```{
  "query": "explain about neural network"
}
```

📤 Response (Partial)

```{
  "query": "explain about neural network",
  "llm_answer": "Answer: A neural network is a computational model inspired by the human brain...",
  "context": {
    "cluster": 2,
    "top_chunks": [...],
    "graph_nodes": [...]
  }
}
```
⸻

### Accuracy & Future Work
  • Accuracy and performance are yet to be fully tested
  • Fine-tuning required based on more structured and high-quality data
  • Currently runs on CPU using the GGUF model format

⸻

### 📸 UI Preview

Streamlit-based interface for asking natural language questions on the repo

![response.png](response.png)


## 🧰 Tech Stack

* Component Tool/Library
* Language Model  DeepSeek Coder 6.7B (GGUF)
* Embeddings  SentenceTransformer: all-MiniLM-L6-v2
* Clustering  Scikit-learn (KMeans, Agglomerative, etc.)
* API Backend FastAPI
* Frontend UI Streamlit
* Vector Indexing SentenceTransformer cosine similarity
* Repo Source TheAlgorithms/Python
* Graphing  Internal structure only (no visualization yet)

⸻


@author **KOLAPALLI VENKATA MURALI KRISHNA**