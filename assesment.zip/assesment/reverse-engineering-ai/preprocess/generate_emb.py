import os
import json
from tqdm import tqdm
from sentence_transformers import SentenceTransformer

# Constants
PROCESSED_FOLDER = "../data/processed"
EMBEDDING_FOLDER = "../data/embeddings"
EMBEDDING_MODEL_PATH = "../models/embedding_model"
CHUNK_SIZE = 500  # Number of characters per chunk

# Ensure embedding directory exists
os.makedirs(EMBEDDING_FOLDER, exist_ok=True)

# Load the embedding model
print("🔄 Loading embedding model...")
model = SentenceTransformer(EMBEDDING_MODEL_PATH)
print("✅ Embedding model loaded.")

def chunk_text(text, size=CHUNK_SIZE):
    """Splits text into chunks of fixed size (with slight overlap)."""
    return [text[i:i+size] for i in range(0, len(text), size)]

def load_processed_files(folder):
    """Load all processed .txt or .md files recursively."""
    files = []
    for root, _, filenames in os.walk(folder):
        for file in filenames:
            if file.endswith((".txt", ".md", ".py", ".java", ".js", ".html", ".md")):
                files.append(os.path.join(root, file))
    return files

def generate_and_store_embeddings():
    files = load_processed_files(PROCESSED_FOLDER)
    print(f"📁 Found {len(files)} processed files.")

    for filepath in tqdm(files, desc="🔍 Generating embeddings"):
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        chunks = chunk_text(content)
        embeddings = model.encode(chunks, show_progress_bar=False)

        # Create a unique filename for embeddings
        relative_path = os.path.relpath(filepath, PROCESSED_FOLDER)
        file_base = os.path.splitext(relative_path)[0].replace(os.sep, "_")
        emb_path = os.path.join(EMBEDDING_FOLDER, f"{file_base}.json")

        # Store chunks + embeddings as a list of dicts
        emb_data = [{"text": chunk, "embedding": emb.tolist()} for chunk, emb in zip(chunks, embeddings)]

        with open(emb_path, "w", encoding="utf-8") as f:
            json.dump(emb_data, f, indent=2)

    print(f"✅ Embeddings stored in {EMBEDDING_FOLDER}")