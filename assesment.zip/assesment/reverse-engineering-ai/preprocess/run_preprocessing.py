# Import your existing functions
from connectors.git_connector import clone_repo
from preprocess.clean_data import clean_all
from preprocess.clustering import perform_clustering
from preprocess.download_models import download_all_models
from preprocess.graph_analysis import build_graph
from preprocess.generate_emb import generate_and_store_embeddings

url = "https://github.com/TheAlgorithms/Python"
def main():
    print("Starting model download...")
    download_all_models()

    print("Cloning repository...")
    clone_repo(url)

    print("Cleaning repository files...")
    clean_all()

    print("Generating embeddings...")
    generate_and_store_embeddings()

    print("Performing clustering...")
    perform_clustering()

    print("Building code graph...")
    build_graph()

    print("Preprocessing complete!")

if __name__ == "__main__":
    main()