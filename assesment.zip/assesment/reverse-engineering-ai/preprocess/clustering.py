import os
import json
import joblib
import numpy as np
from sklearn.cluster import KMeans
from tqdm import tqdm

# Constants
EMBEDDING_FOLDER = "../data/embeddings"
CLUSTER_MODEL_PATH = "../data/cluster/kmeans_model.joblib"
N_CLUSTERS = 8  # You can tune this

def load_all_embeddings():
    embeddings = []
    for file in tqdm(os.listdir(EMBEDDING_FOLDER), desc="📦 Loading embeddings"):
        if not file.endswith(".json"):
            continue
        file_path = os.path.join(EMBEDDING_FOLDER, file)
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for item in data:
                    embeddings.append(item["embedding"])
        except Exception as e:
            print(f"⚠️ Skipping file due to error: {file_path} -> {e}")
    return np.array(embeddings, dtype=np.float32)

def perform_clustering():
    print("🔍 Loading all embeddings...")
    X = load_all_embeddings()
    print(f"✅ Loaded {len(X)} embeddings.")

    print(f"🔄 Performing KMeans clustering (k={N_CLUSTERS})...")
    kmeans = KMeans(n_clusters=N_CLUSTERS, random_state=42, n_init="auto")
    kmeans.fit(X)

    print(f"💾 Saving clustering model to: {CLUSTER_MODEL_PATH}")
    os.makedirs(os.path.dirname(CLUSTER_MODEL_PATH), exist_ok=True)
    joblib.dump(kmeans, CLUSTER_MODEL_PATH)
    print("✅ Clustering model saved.")

# if __name__ == "__main__":
#     perform_clustering()