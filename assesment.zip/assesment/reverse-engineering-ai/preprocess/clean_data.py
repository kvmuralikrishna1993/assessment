# preprocess/clean_data.py

import os
from pathlib import Path
import pytesseract
from PIL import Image
from langdetect import detect
import chardet

TEXT_EXTENSIONS = {".txt", ".md", ".rst"}
CODE_EXTENSIONS = {".py", ".js", ".java", ".cpp", ".c", ".html", ".css", ".json", ".xml", ".sh"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg"}

RAW_DIR = Path("../data/raw")
PROCESSED_DIR = Path("../data/processed")
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


def is_english(text):
    try:
        return detect(text) == "en"
    except:
        return False


def read_file(path):
    try:
        with open(path, "rb") as f:
            raw = f.read()
            encoding = chardet.detect(raw)["encoding"]
            return raw.decode(encoding or "utf-8", errors="ignore")
    except Exception as e:
        print(f"Error reading {path}: {e}")
        return ""


def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        return pytesseract.image_to_string(image)
    except Exception as e:
        print(f"Error extracting image text from {image_path}: {e}")
        return ""


def clean_repo(raw_repo_path, processed_repo_path):
    for root, _, files in os.walk(raw_repo_path):
        for file in files:
            ext = Path(file).suffix.lower()
            raw_file_path = Path(root) / file
            relative_path = raw_file_path.relative_to(RAW_DIR)
            out_file_path = processed_repo_path / relative_path.with_suffix(".txt")
            out_file_path.parent.mkdir(parents=True, exist_ok=True)

            text = ""
            if ext in TEXT_EXTENSIONS or ext in CODE_EXTENSIONS:
                text = read_file(raw_file_path)
            elif ext in IMAGE_EXTENSIONS:
                text = extract_text_from_image(raw_file_path)

            if text and is_english(text):
                with open(out_file_path, "w", encoding="utf-8") as f:
                    f.write(text)


def clean_all():
    for repo in RAW_DIR.iterdir():
        if repo.is_dir():
            print(f"Cleaning {repo.name}")
            processed_repo_path = PROCESSED_DIR / repo.name
            clean_repo(repo, processed_repo_path)