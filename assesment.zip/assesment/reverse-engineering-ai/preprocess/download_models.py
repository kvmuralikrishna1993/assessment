# preprocess/download_models.py

import os
import joblib
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
from huggingface_hub import snapshot_download
import shutil

# Constants
EMBED_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
EMBED_MODEL_PATH = "../models/embedding_model"
CLUSTER_MODEL_PATH = "../models/clustering_model"
LLM_MODEL_REPO = "TheBloke/deepseek-coder-6.7B-instruct-GGUF"
LLM_MODEL_FILENAME = "deepseek-coder-6.7b-instruct.Q4_K_M.gguf"
LLM_MODEL_PATH = f"../models/local_llm/{LLM_MODEL_FILENAME}"

def download_embedding_model():
    os.makedirs(EMBED_MODEL_PATH, exist_ok=True)
    print(f"Downloading embedding model: {EMBED_MODEL_NAME}")
    model = SentenceTransformer(EMBED_MODEL_NAME)
    model.save(EMBED_MODEL_PATH)
    print("✓ Embedding model saved.")

def create_dummy_clustering_model():
    os.makedirs(CLUSTER_MODEL_PATH, exist_ok=True)
    print("Creating dummy clustering model (to be trained later)...")
    dummy = KMeans(n_clusters=5)
    joblib.dump(dummy, os.path.join(CLUSTER_MODEL_PATH, "kmeans_model.joblib"))
    print("✓ Clustering model stub saved.")

def download_llm_model():
    os.makedirs(os.path.dirname(LLM_MODEL_PATH), exist_ok=True)
    if not os.path.exists(LLM_MODEL_PATH):
        print(f"Downloading LLM model: {LLM_MODEL_FILENAME}")
        # Download the specific file from the Hugging Face repository
        snapshot_dir = snapshot_download(repo_id=LLM_MODEL_REPO, allow_patterns=LLM_MODEL_FILENAME)
        source_path = os.path.join(snapshot_dir, LLM_MODEL_FILENAME)
        shutil.copy(source_path, LLM_MODEL_PATH)
        print("✓ Local LLM model downloaded.")
    else:
        print("✓ Local LLM model already exists.")

def download_all_models():
    download_embedding_model()
    create_dummy_clustering_model()
    download_llm_model()