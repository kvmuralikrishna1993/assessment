import os
import re
import json
import networkx as nx

PROCESSED_DIR = "../data/processed"  # Your extracted text files path
GRAPH_OUTPUT_PATH = "../data/graph/code_graph.json"

# Simple regex patterns for generic "class" and "function" definitions
# (can be tweaked to support more languages)
CLASS_PATTERN = re.compile(r'^\s*(class|interface|struct)\s+(\w+)', re.MULTILINE)
FUNC_PATTERN = re.compile(r'^\s*(def|function|func|fn)\s+(\w+)', re.MULTILINE)

def extract_generic_graph(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except UnicodeDecodeError:
        print(f"⚠️ Skipping non-text or unreadable file: {filepath}")
        return nx.DiGraph()  # return empty graph for this file

    G = nx.DiGraph()
    current_file = os.path.basename(filepath)
    G.add_node(current_file, type="file")

    # rest of your code unchanged...
    for match in CLASS_PATTERN.finditer(content):
        cls_name = match.group(2)
        G.add_node(cls_name, type="class")
        G.add_edge(current_file, cls_name)

    for match in FUNC_PATTERN.finditer(content):
        func_name = match.group(2)
        G.add_node(func_name, type="function")
        G.add_edge(current_file, func_name)

    return G

def build_graph():
    overall_graph = nx.DiGraph()

    for root, _, files in os.walk(PROCESSED_DIR):
        for file in files:
            path = os.path.join(root, file)
            file_graph = extract_generic_graph(path)
            overall_graph = nx.compose(overall_graph, file_graph)

    print(f"✓ Graph built with {overall_graph.number_of_nodes()} nodes and {overall_graph.number_of_edges()} edges")

    graph_dict = nx.readwrite.json_graph.node_link_data(overall_graph)
    os.makedirs(os.path.dirname(GRAPH_OUTPUT_PATH), exist_ok=True)
    with open(GRAPH_OUTPUT_PATH, "w") as f:
        json.dump(graph_dict, f, indent=2)

    print(f"✓ Graph saved to {GRAPH_OUTPUT_PATH}")
